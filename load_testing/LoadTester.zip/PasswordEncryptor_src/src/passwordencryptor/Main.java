/*
 * To generate a private and public key pair needed for this example I used openssl:
 * openssl genrsa -out private_key.pem
 * openssl pkcs8 -topk8 -inform PEM -in private_key.pem -outform DER -out private_key.der -nocrypt
 * openssl rsa -in private_key.pem -outform DER -pubout -out public_key.der
 */

package passwordencryptor;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import javax.crypto.Cipher;
import org.apache.axis.encoding.Base64;

/**
 *
 * @author rhofstet
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Base64 b64 = new Base64();
        File private_key_der = new File("C:\\temp\\private_key.der");
        File public_key_der = new File("C:\\temp\\public_key.der");

        try {
           // Read the public key in from a key file
            FileInputStream fis = new FileInputStream(public_key_der);
            DataInputStream dis = new DataInputStream(fis);
            byte[] keyBytes = new byte[(int)public_key_der.length()];
            dis.readFully(keyBytes);
            dis.close();

            // Reconstruct the public key object using byte array read from public key file
            X509EncodedKeySpec pub_spec = new X509EncodedKeySpec(keyBytes);
            KeyFactory keyFac = KeyFactory.getInstance("RSA");
            PublicKey rsaPubKey = keyFac.generatePublic(pub_spec);

            // Create RSA Cipher
            Cipher rsaCipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            // Initialize Cipher for encryption using the public key
            rsaCipher.init(Cipher.ENCRYPT_MODE, rsaPubKey);

            // Encrypt the clear text and print out the resultant binary 64 representation
            String theEncPassword = b64.encode(rsaCipher.doFinal(args[0].getBytes()));
            System.out.println(theEncPassword);

            // Now decrypt the encrypted password
            // Read the private key in from a key file
            fis = new FileInputStream(private_key_der);
            dis = new DataInputStream(fis);
            keyBytes = new byte[(int)private_key_der.length()];
            dis.readFully(keyBytes);
            dis.close();

            // Reconstruct the private key object using byte array read from private key file
            PKCS8EncodedKeySpec priv_spec = new PKCS8EncodedKeySpec(keyBytes);
            PrivateKey rsaPrivKey = keyFac.generatePrivate(priv_spec);

            // Initialize Cipher for decryption using the private key
            rsaCipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            rsaCipher.init(Cipher.DECRYPT_MODE, rsaPrivKey);

            // Decrypt the binary 64 encoded encoded cipher text and reassemble the bytes into a string
            byte[] decoded_bytes = rsaCipher.doFinal(b64.decode(theEncPassword));
            String thePassword = new String(decoded_bytes, "UTF8");
            System.out.println(thePassword);
        }
        catch (java.security.NoSuchAlgorithmException ex) {
            ex.printStackTrace();
        }
        catch (javax.crypto.NoSuchPaddingException ex) {
            ex.printStackTrace();
        }
        catch (javax.crypto.BadPaddingException ex) {
            ex.printStackTrace();
        }
        catch (java.security.spec.InvalidKeySpecException ex) {
            ex.printStackTrace();
        }
        catch (java.security.InvalidKeyException ex) {
            ex.printStackTrace();
        }
        catch (javax.crypto.IllegalBlockSizeException ex) {
            ex.printStackTrace();
        }
        catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
