import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.PKCS8EncodedKeySpec;
import javax.crypto.Cipher;

import com.ibm.xml.crypto.util.Base64;

public class encrypt {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        File private_key_der = new File("private.der");
        File certificate_der = new File("certificate.der");

        try {
            // Reconstruct the X509 certificate object from certificate file
        	FileInputStream fis = new FileInputStream(certificate_der);
        	CertificateFactory certificateFactory = CertificateFactory.getInstance("X.509");
            X509Certificate certificate = (X509Certificate)certificateFactory.generateCertificate(fis);
            certificate.checkValidity();
            
            // Create the encryption cipher from the certificate's public key
            PublicKey rsaPubKey = certificate.getPublicKey();
            Cipher x509Cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            x509Cipher.init(Cipher.ENCRYPT_MODE, rsaPubKey);
            
            // Encrypt the clear text and print out the resultant binary 64 representation
            String theEncPassword = Base64.encode(x509Cipher.doFinal(args[0].getBytes()));
            System.out.println("The encrypted length is " + theEncPassword.length());
            System.out.println(theEncPassword);

            // Reconstruct the private key from key file
            fis = new FileInputStream(private_key_der);
            DataInputStream dis = new DataInputStream(fis);
            byte[]  keyBytes = new byte[(int)private_key_der.length()];
            dis.readFully(keyBytes);
            dis.close();
            PKCS8EncodedKeySpec priv_spec = new PKCS8EncodedKeySpec(keyBytes);
            KeyFactory keyFac = KeyFactory.getInstance("RSA");
            PrivateKey rsaPrivKey = keyFac.generatePrivate(priv_spec);

            // Create the reverse encryption cipher from private key file
            Cipher rsaCipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            rsaCipher.init(Cipher.DECRYPT_MODE, rsaPrivKey);

            // Decode the binary 64 encoded cipher text and reassemble the bytes into a string
            byte[] decoded_bytes = rsaCipher.doFinal(Base64.decode(theEncPassword));
            String thePassword = new String(decoded_bytes, "UTF8");
            System.out.println(thePassword);
        }
        catch (java.security.NoSuchAlgorithmException ex) {
            ex.printStackTrace();
        }
        catch (javax.crypto.NoSuchPaddingException ex) {
            ex.printStackTrace();
        }
        catch (javax.crypto.BadPaddingException ex) {
            ex.printStackTrace();
        }
        catch (java.security.spec.InvalidKeySpecException ex) {
            ex.printStackTrace();
        }
        catch (java.security.InvalidKeyException ex) {
            ex.printStackTrace();
        }
        catch (javax.crypto.IllegalBlockSizeException ex) {
            ex.printStackTrace();
        }
        catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }
        catch (IOException ex) {
            ex.printStackTrace();
        } catch (CertificateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
}
