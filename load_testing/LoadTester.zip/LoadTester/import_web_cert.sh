#!/bin/sh
#
#  Licensed Materials - Property of IBM
#  
#  (C) Copyright IBM Corp. 2005, 2010
#  
#  US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with
#  IBM Corp.
#
#  Copyright (C) 2008 Cognos ULC, an IBM Company. All rights reserved.
#  Cognos (R) is a trademark of Cognos ULC, (formerly Cognos Incorporated).
#
# CHANGE the following environment variables to point to IBM Cognos on your system.

if [ "$CRN_HOME" = "" ] ; then
	CRN_HOME=../../../
fi
if [ "$JAVA_HOME" = "" ] ; then
	JAVA_HOME=$CRN_HOME/jre
fi
if [ $# -lt 2 ] ; then
	echo "Usage: $0 certificate-alias certificate-path"
        echo "eg: $0 mywebserver ./mywebserver.crt"
	exit 1
fi



if [ ! -f $2 ] ; then
	echo "The certificate file specified does not exist. Please export the web server certificate to be imported"
	exit 1
fi


KEYTOOL=$JAVA_HOME/bin/keytool

# Import web server certificate to the Java keystore
$KEYTOOL -keystore $JAVA_HOME/lib/security/cacerts -importcert -alias "$1" -file "$2" 

