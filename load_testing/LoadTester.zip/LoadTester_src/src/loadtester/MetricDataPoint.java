package loadtester;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;

public class MetricDataPoint {
	private Instant timeStamp;
	private int duration;
	private String host;
	private String threadName;
	private String threadStep;
	private String status;
	private double cpu;
	private double mem;
	private double disk;
	
	MetricDataPoint (Instant t, int d, String h, String n, String s, boolean success, double servercpu, double servermem, double serverdisk) {
		timeStamp = t;
		duration = d;
		host = h;
		threadName = n;
		threadStep = s;
		status = success ? "Success" : "Failure";
		cpu = servercpu;
		mem = servermem;
		disk = serverdisk;
	}
	
	public String toString() {
		String csvData = new String();
		LocalDateTime ldt = LocalDateTime.ofInstant(timeStamp, ZoneId.systemDefault());
		csvData = String.format("%02d:%02d:%02d", ldt.getHour(), ldt.getMinute(), ldt.getSecond());
		csvData += "," + Integer.toString(duration);
		csvData += ",\"" + host + "\"";
		csvData += ",\"" + threadName + "\"";
		csvData += ",\"" + threadStep + "\"";
		csvData += ",\"" + status + "\"";
		
		// round the value
		BigDecimal bdcpu = new BigDecimal(cpu).setScale(2, BigDecimal.ROUND_HALF_UP);
		double temp = bdcpu.doubleValue();
		csvData += "," + Double.toString(temp);
		
		// convert bytes to gigabytes
		temp = mem / 1073741824;
		BigDecimal bdmem = new BigDecimal(temp).setScale(2, BigDecimal.ROUND_HALF_UP);
		temp = bdmem.doubleValue();
		csvData += "," + Double.toString(temp);
		
		bdcpu = new BigDecimal(disk).setScale(2, BigDecimal.ROUND_HALF_UP);
		temp = bdcpu.doubleValue();
		csvData += "," + Double.toString(temp);
		
		return csvData;
	}
}
