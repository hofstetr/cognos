package loadtester;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.rmi.RemoteException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Hashtable;

import javax.xml.namespace.QName;
import javax.xml.rpc.ServiceException;

import com.cognos.org.apache.axis.encoding.Base64;

import com.cognos.developer.schemas.bibus._3.AsynchDetailReportOutput;
import com.cognos.developer.schemas.bibus._3.AsynchDetailReportStatus;
import com.cognos.developer.schemas.bibus._3.AsynchDetailReportStatusEnum;
import com.cognos.developer.schemas.bibus._3.AsynchOptionBoolean;
import com.cognos.developer.schemas.bibus._3.AsynchOptionEnum;
import com.cognos.developer.schemas.bibus._3.AsynchReply;
import com.cognos.developer.schemas.bibus._3.AsynchReplyStatusEnum;
import com.cognos.developer.schemas.bibus._3.AsynchSecondaryRequest;
import com.cognos.developer.schemas.bibus._3.AuthoredReport;
import com.cognos.developer.schemas.bibus._3.BaseClass;
import com.cognos.developer.schemas.bibus._3.BiBusHeader;
import com.cognos.developer.schemas.bibus._3.ContentManagerService_PortType;
import com.cognos.developer.schemas.bibus._3.ContentManagerService_ServiceLocator;
import com.cognos.developer.schemas.bibus._3.CookieVar;
import com.cognos.developer.schemas.bibus._3.HdrSession;
import com.cognos.developer.schemas.bibus._3.Option;
import com.cognos.developer.schemas.bibus._3.OrderEnum;
import com.cognos.developer.schemas.bibus._3.ParameterValue;
import com.cognos.developer.schemas.bibus._3.PropEnum;
import com.cognos.developer.schemas.bibus._3.QueryOptions;
import com.cognos.developer.schemas.bibus._3.ReportService_PortType;
import com.cognos.developer.schemas.bibus._3.ReportService_ServiceLocator;
import com.cognos.developer.schemas.bibus._3.ReportView;
import com.cognos.developer.schemas.bibus._3.RoutingInfo;
import com.cognos.developer.schemas.bibus._3.RunOptionBoolean;
import com.cognos.developer.schemas.bibus._3.RunOptionEnum;
import com.cognos.developer.schemas.bibus._3.RunOptionStringArray;
import com.cognos.developer.schemas.bibus._3.SearchPathMultipleObject;
import com.cognos.developer.schemas.bibus._3.SearchPathSingleObject;
import com.cognos.developer.schemas.bibus._3.Sort;
import com.cognos.developer.schemas.bibus._3.XmlEncodedXML;
import com.cognos.org.apache.axis.client.Stub;
import com.cognos.org.apache.axis.message.SOAPHeaderElement;
import com.cognos.org.apache.axis.transport.http.HTTPConstants;


public class UserThread extends Thread {
	private String namespace;
	private String passport;
	private String userid;
	private String password;
	private String dispatcher;
	private String host;
	private ReportDetails[] reports;
	private int think;
	private boolean status;
	boolean loggedon = false;
	private ThreadMetrics metrics;
	
	private volatile boolean runflag = true;
	private static final String BIBUS_NS = "http://developer.cognos.com/schemas/bibus/3/";
    private static final String BIBUS_HDR = "biBusHeader";
	private static final QName BUS_QNAME = new QName(BIBUS_NS, BIBUS_HDR);
	
	private ContentManagerService_ServiceLocator cmServiceLocator = null;
	private ReportService_ServiceLocator reportServiceLocator = null;

	private ContentManagerService_PortType cmService = null;
	private ReportService_PortType reportService = null;

	private String BiBus_NS = "http://developer.cognos.com/schemas/bibus/3/";
	private String BiBus_H = "biBusHeader";
	
	UserThread(ThreadDetails details) {
		setName(details.getThreadName());
		namespace = details.getNamespace();
		passport = details.getPassport();
		userid = details.getUserID();
		password = details.getUserPWD();
		
		dispatcher = details.getDispatcher();
		reports = details.getReportDetails();
		think = details.getThinkTime();
		
		// Parse the host from the dispatcher URL
		if (dispatcher.indexOf("https") > -1) {
			host = dispatcher.substring(8);
		}
		else {
			host = dispatcher.substring(7);
		}
		if (host.indexOf(":") > 0) {
			host = host.substring(0, host.indexOf(":"));
		}
		else {
			host = host.substring(0, host.indexOf("/"));
		}

		cmServiceLocator = new ContentManagerService_ServiceLocator();
		reportServiceLocator = new ReportService_ServiceLocator();
		
			java.net.URL serverURL;
			try {
				serverURL = new java.net.URL(dispatcher);
				cmService = cmServiceLocator.getcontentManagerService(serverURL);
				reportService = reportServiceLocator.getreportService(serverURL);
			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ServiceException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	
	public void setThreadMetrics(ThreadMetrics m) {
		metrics = m;
	}
	
	/**
	 * Log on to Cognos Analytics using thread's credentials
	 */
	public boolean logonWithCreds() {
		StringBuffer credentialXML = new StringBuffer();
		
		credentialXML.append("<credential>");
		credentialXML.append("<namespace>").append(namespace).append("</namespace>");
		credentialXML.append("<operatorname>").append(userid).append("</operatorname>");
		credentialXML.append("<operatortoken>").append(password).append("</operatortoken>");
		credentialXML.append("</credential>");

		String encodedCredentials = credentialXML.toString();
		XmlEncodedXML xmlCredentials = new XmlEncodedXML();
		xmlCredentials.set_value(encodedCredentials);
        try {
			((Stub)cmService).clearHeaders();
			cmService.logon(xmlCredentials, null);
			getSetHeaders();
		} catch (RemoteException e) {
			System.out.println("Thread, " + getName() + ", failed to log on with " + userid + " with password " + password + ".");
			status = false;
			return false;
		}
		return true;
	}
	
	/**
	 * Log on to Cognos Analytics using thread's passport
	 */
	public boolean logonWithPassport() {
        HdrSession header = new HdrSession();
        CookieVar[] vars = new CookieVar[1];
        vars[0] = new CookieVar();
        vars[0].setName("cam_passport");
        vars[0].setValue(passport);
        header.setCookieVars(vars);
        BiBusHeader bibus = new BiBusHeader();
        bibus.setHdrSession(header);
        ((Stub)cmService).setHeader("http://developer.cognos.com/schemas/bibus/3/", "biBusHeader", bibus);

        try {
        	cmService.query(new SearchPathMultipleObject("~"), new PropEnum[] { PropEnum.searchPath, PropEnum.defaultName}, new Sort[] {}, new QueryOptions());
        } catch (RemoteException e) {
        	System.out.println("Thread, " + getName() + ", failed to log on with passport " + passport);
        	status = false;
        	return false;
	}
        
		return true;
	}
	
	/**
	 * Log on to Cognos Analytics using SSO with thread's user ID
	 */
	@SuppressWarnings("unchecked")
	public boolean logonSSO() {
		try {
			((Stub)cmService).clearHeaders();
			Hashtable<String, String> userHeaderTable = (Hashtable<String, String>)((Stub)cmService)._getProperty(HTTPConstants.REQUEST_HEADERS);
			if (userHeaderTable == null) {
				userHeaderTable = new Hashtable<String, String>();
			}
			userHeaderTable.put("CAM-Namespace", namespace);
			userHeaderTable.put("iv-user", userid);
			((Stub)cmService)._setProperty(HTTPConstants.REQUEST_HEADERS, userHeaderTable);
			cmService.query(new SearchPathMultipleObject("~"), new PropEnum[] { PropEnum.searchPath, PropEnum.defaultName}, new Sort[] {}, new QueryOptions());
			getSetHeaders();
		} catch (RemoteException e) {
			System.out.println("Thread, " + getName() + ", failed to log on with single sign on.");
			status = false;
			return false;
		}
		return true;
	}
	
	// sn_dg_sdk_mng_svc_hdrs_start_1
    public ReportService_PortType getReportService(boolean isNewConversation, String RSGroup) {
    	BiBusHeader bibus = null;
    	SOAPHeaderElement SourceHeader = ((Stub)reportService).getResponseHeader(BiBus_NS, BiBus_H);
    	if (SourceHeader == null || isNewConversation) {
    		SourceHeader = ((Stub)cmService).getResponseHeader(BiBus_NS, BiBus_H);
    		try {
				bibus = (BiBusHeader)SourceHeader.getValueAsType(BUS_QNAME);
				if (RSGroup.length()>0) {
                    RoutingInfo routing = new RoutingInfo(RSGroup);
                    bibus.setRouting(routing);
                }
                else {
                    bibus.setRouting(null);
                }
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    	}
    	else {
			try {
				bibus = (BiBusHeader)SourceHeader.getValueAsType(BUS_QNAME);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }

        ((Stub)reportService).clearHeaders();
        ((Stub)reportService).setHeader(BiBus_NS, BiBus_H, bibus);
        return reportService;
    }

	
	public void logoff() {
		try {
			cmService.logoff();
			((Stub)cmService).clearHeaders();
		} catch (RemoteException e) {
			System.out.println("Thread, " + getName() + ", failed to log off.");
			e.printStackTrace();
			status = false;
		} catch (Exception e) {
			System.out.println("Thread, " + getName() + ", failed to log off.");
			e.printStackTrace();
		}
	}
	
	public void getSetHeaders() {
		BiBusHeader CMbibus = null;
		SOAPHeaderElement temp = ((Stub)cmService).getResponseHeader(BiBus_NS, BiBus_H);
		try	{
			CMbibus = (BiBusHeader)temp.getValueAsType(new QName(BiBus_NS, BiBus_H));
		}
		catch (Exception e)	{
			System.out.println("Thread, " + getName() + ", failed to log on.");
			status = false;
		}

		if (CMbibus != null) {
			((Stub)cmService).setHeader(BiBus_NS, BiBus_H, CMbibus);
			((Stub)reportService).clearHeaders();
			//((Stub)reportService).setHeader(BiBus_NS, BiBus_H, CMbibus);
		}
	}
	
	public static boolean hasSecondaryRequest(AsynchReply response, String secondaryRequest) {
		AsynchSecondaryRequest[] secondaryRequests = response.getSecondaryRequests();
		for (int i = 0; i < secondaryRequests.length; i++) {
			if (secondaryRequests[i].getName().compareTo(secondaryRequest) == 0) {
				return true;
			}
		}
		return false;
	}
	
	public boolean outputIsReady(AsynchReply response) {
		for (int i = 0; i < response.getDetails().length; i++) {
			if ((response.getDetails()[i] instanceof AsynchDetailReportStatus) && (((AsynchDetailReportStatus)response.getDetails()[i]).getStatus()
					== AsynchDetailReportStatusEnum.responseReady)
				&& (hasSecondaryRequest(response, "getOutput"))) {
				return true;
			}
		}
		return false;
	}
	
	public String getOutputPage(AsynchReply response) {
		AsynchDetailReportOutput reportOutput = null;
		for (int i = 0; i < response.getDetails().length; i++) {
			if (response.getDetails()[i] instanceof AsynchDetailReportOutput) {
				reportOutput = (AsynchDetailReportOutput)response.getDetails()[i];
				break;
			}
		}

		//text based output is split into pages -- binary output is all on one page, return the first page
		return reportOutput.getOutputPages()[0];
	}
	
	public void end() {
		runflag = false;
	}
	
	public void run() {
		while(runflag) {
			long startLogon = System.nanoTime();
			// Step 1: Log on
			if (!loggedon) {
				status = true;
				if (passport != null) {
					loggedon = logonWithPassport();
				}
				else if (password.compareTo("NoPassword") == 0) {
					loggedon = logonSSO();
				}
				else if (userid.compareToIgnoreCase("anonymous") == 0){
					loggedon = true;
				}
				else {
					loggedon = logonWithCreds();
				}
			}
			if (loggedon) {
				long endLogon = System.nanoTime();
				double duration = (double) ((endLogon - startLogon) / 1e9);
				metrics.add(Instant.now(), (int)Math.round(duration), host, this.getName(), "logon", status, 0, 0, 0);
	
				try {
					Thread.sleep(think * 1000);
				} catch (InterruptedException e) {
					// If we are interrupted it is probably to shut down
					end();
				}
				
				// Step 2: Loop through each report
				for (int x=0; x<reports.length; x++) {

					long startReport = System.nanoTime();
					status = true;
					// Step 4: Run report
					try {
						Option[] runOptions = new Option[4];
	
						RunOptionBoolean saveOutput = new RunOptionBoolean();
						saveOutput.setName(RunOptionEnum.saveOutput);
						saveOutput.setValue(false);
						runOptions[0] = saveOutput;
	
						// Specify the output format.
						RunOptionStringArray outputFormat = new RunOptionStringArray();
						outputFormat.setName(RunOptionEnum.outputFormat);
						outputFormat.setValue(new String[] { reports[x].getFormat() });
						runOptions[1] = outputFormat;
	
						//Set the report not to prompt as we pass the parameters if any
						RunOptionBoolean rop = new RunOptionBoolean();
						rop.setName(RunOptionEnum.prompt);
						rop.setValue(false);
						runOptions[2] = rop;
						
						// Specify to always include the primary request
						AsynchOptionBoolean includePrimaryRequest = new AsynchOptionBoolean();
						includePrimaryRequest.setName(AsynchOptionEnum.alwaysIncludePrimaryRequest);
                        includePrimaryRequest.setValue(true);
                        runOptions[3] = includePrimaryRequest;
                        
                        // Add any specified parameter values from the scenario
                        ParameterValue[] parameters = null;
                        if (reports[x].getParameterCount() > 0) {
                        	parameters = new ParameterValue[reports[x].getParameterCount()];
                        	for (int i=0; i<reports[x].getParameterCount(); i++) {
                        		parameters[i] = reports[x].getParameterValue(i);
                        	}
                        }
                        
                        //check for advanced routing server group
                        PropEnum props[] = new PropEnum[] { PropEnum.searchPath, PropEnum.defaultName, PropEnum.canBurst, PropEnum.routingServerGroup };
                        Sort sortOptions[] = { new Sort()};
                        sortOptions[0].setOrder(OrderEnum.ascending);
                        sortOptions[0].setPropName(PropEnum.defaultName);

                        BaseClass reportarray[] = cmService.query(new SearchPathMultipleObject(reports[x].getPath()), props, sortOptions, new QueryOptions());
                        if (reportarray.length < 1) {
                        	System.out.println("Report object not found at path " + reports[x].getPath());
                        }
                        else {
                        	String serverGroup = null;
                        	
                        	// check if this is a report or a report view and fetch the server group tag appropriately
                        	if (reportarray[0] instanceof ReportView) {
                        		serverGroup = ((ReportView)reportarray[0]).getRoutingServerGroup().getValue();
                        	}
                        	else {
                        		serverGroup = ((AuthoredReport)reportarray[0]).getRoutingServerGroup().getValue();
                        	}
	                        if(serverGroup == null) {
	                            serverGroup = "";
	                        }

							AsynchReply res1 = getReportService(true, serverGroup).run(new SearchPathSingleObject(reports[x].getPath()), parameters, runOptions);
							// If response is not immediately complete, call wait until complete
			                if (!res1.getStatus().equals(AsynchReplyStatusEnum.complete) && !res1.getStatus().equals(AsynchReplyStatusEnum.conversationComplete)) {
			                	while (!res1.getStatus().equals(AsynchReplyStatusEnum.complete) && !res1.getStatus().equals(AsynchReplyStatusEnum.conversationComplete)) {
			                		//before calling wait, double check that it is okay
			                		if (!hasSecondaryRequest(res1, "wait")) {
			                			System.out.println("Error with secondary report request");
			                		}
			                		else {
			                			res1 = getReportService(false, "").wait(res1.getPrimaryRequest(), new ParameterValue[] {}, new Option[] {});
			                		}
			                	}
		
				                //After calling wait() it is necessary to check if the output needs to be retrieved and not already in the response
				                if (outputIsReady(res1)) {
				                	res1 = getReportService(false, "").getOutput(res1.getPrimaryRequest(), new ParameterValue[] {}, new Option[] {});
				                }
		                	}
			                
			                // Save the first output page if required
		                	if (reports[x].getSaveState()) {
			                	String data = getOutputPage(res1);
			                	Instant rightnow = Instant.now();
			                	LocalDateTime ldt = LocalDateTime.ofInstant(rightnow, ZoneId.systemDefault());
			                	if (reports[x].getFormat().compareToIgnoreCase("HTML") == 0) {
			                		File oFile = new File(reports[x].getOutputPath() + reports[x].getName() + "-" + ldt.getHour() + ldt.getMinute() + ldt.getSecond() + ".html");
			                		FileOutputStream fos = new FileOutputStream(oFile);
			                		fos.write(data.getBytes());
			                		fos.flush();
			                		fos.close();
			                	}
			                	else if (reports[x].getFormat().compareToIgnoreCase("PDF") == 0) {
			                		File oFile = new File(reports[x].getOutputPath() + reports[x].getName() + "-" + ldt.getHour() + ldt.getMinute() + ldt.getSecond() + ".pdf");
			                		FileOutputStream fos = new FileOutputStream(oFile);
			                		fos.write(Base64.decode(data));
			                		fos.flush();
			                		fos.close();
			                	}
			                	else {
			                		System.out.println("Output format for " + reports[x].getName() + " of " + reports[x].getFormat() + " is not yet supported for saving. Please disable save feature.");
			                	}
		                	}
                        }
					} catch (RemoteException e) {
						System.out.println("Failed to run report " + reports[x].getName() + " on thread " + this.getName());
						e.printStackTrace();
						status = false;
					} catch (FileNotFoundException e) {
						System.out.println("Unable to save output");
						e.printStackTrace();
					} catch (IOException e) {
						System.out.println("Unable to save output");
						e.printStackTrace();
					}
					
					long endReport = System.nanoTime();
					duration = (double) ((endReport - startReport) / 1e9);
					metrics.add(Instant.now(), (int)duration, host, this.getName(), reports[x].getName(), status, 0, 0, 0);
					
					try {
						Thread.sleep(think * 1000);
					} catch (InterruptedException e) {
						// If we are interrupted it is probably to shut down
						end();
					}
				}
			}
			
			// Step 5: Log off
			if (passport == null) {
				logoff();
				loggedon = false;
			}
			try {
				Thread.sleep(think * 1000);
			} catch (InterruptedException e) {
				// If we are interrupted it is probably to shut down
				end();
			}
		}
	}
}