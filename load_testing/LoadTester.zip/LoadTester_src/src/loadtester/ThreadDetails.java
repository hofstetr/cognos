package loadtester;

public class ThreadDetails {
	private String ThreadName;
	private String Namespace;
	private String UserID;
	private String UserPWD;
	private String Passport;
	private ReportDetails reports[];
	private String Dispatcher;
	private int ThinkTime = -1;
	
	ThreadDetails () {}
	
	public String getThreadName () {
		return ThreadName;
	}
	public String getNamespace () {
		return Namespace;
	}
	public String getUserID () {
		return UserID;
	}
	public String getUserPWD () {
		return UserPWD;
	}
	public String getDispatcher () {
		return Dispatcher;
	}
	public int getThinkTime () {
		return ThinkTime;
	}
	public String getPassport () {
		return Passport;
	}
	public ReportDetails[] getReportDetails () {
		return reports;
	}
	public boolean isComplete() {
		if (ThreadName == null) {
			return false;
		}
		if (Passport == null) {
			if (Namespace == null) {
				return false;
			}
			if (UserID == null) {
				return false;
			}
			if (UserPWD == null) {
				return false;
			}
		}
		if (Dispatcher == null) {
			return false;
		}
		if (reports == null) {
			return false;
		}
		if (ThinkTime == -1) {
			return false;
		}
		return true;
	}
	public void setThreadName (String threadname) {
		ThreadName = threadname;
	}
	public void setNamespace (String namespace) {
		Namespace = namespace;
	}
	public void setUserID (String userid) {
		UserID = userid;
	}
	public void setUserPWD (String userpwd) {
		UserPWD = userpwd;
	}
	public void setDispatcher (String dispatcher) {
		Dispatcher = dispatcher;
	}
	public void setThinkTime (int thinktime) {
		ThinkTime = thinktime;
	}
	public void setPassport (String passport) {
		Passport = passport;
	}
	
	public void setReportDetails (ReportDetails[] details) {
		reports = details;
	}
}
