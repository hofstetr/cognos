package loadtester;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.Vector;

public class ThreadGroup {

	public static void main(String[] args) {
		int rampup = 0;
		int rampdown = 0;
		int duration = 0;
		int threadcount = 0;
		int agentcount = 0;
		
		ThreadMetrics metrics = new ThreadMetrics();
		ScenarioLoader scenario = new ScenarioLoader("scenario.xml");
		
		if (scenario.isLoaded()) {
		    rampup = scenario.getRampup();
		    rampdown = scenario.getRampDown();
		    duration = scenario.getDuration();
		    
		    // Determine total number of user threads
		    for (int x=0; x<scenario.getThreadCount(); x++) {
		    	threadcount += scenario.getThreadCount(x);
		    }
		    UserThread sut[] = new UserThread[threadcount];
			AgentThread sat[] = null;

			String hosts[] = scenario.getServerAgents();
			String freq[] = scenario.getAgentFrequencies();
			if (hosts != null && hosts.length > 0 && freq.length > 0) {
				System.out.println("Starting agent threads");
				sat = new AgentThread[hosts.length];
				for (int x=0; x<hosts.length; x++) {
					String host[] = hosts[x].split(":");
					if (host.length == 2) {
						sat[agentcount] = new AgentThread(host[0], Integer.parseInt(host[1]), Integer.parseInt(freq[x]));
						sat[agentcount].setThreadMetrics(metrics);
						sat[agentcount].setName("ServerAgent" + (x+1));
						sat[agentcount].start();
						agentcount++;
					}
					else {
						System.out.println("Malformed serveragent " + hosts[x] + ". Server metrics will not be collected.");
					}
				}
			}
			else {
				System.out.println("Missing serveragents or recording frequencies. Server metrics will not be collected");
			}
			
			System.out.println("Starting user threads");
			threadcount = 0;
			for (int x=0; x<scenario.getThreadCount(); x++) {
				ThreadDetails theDetails = scenario.getThreadDetails(x);
				if (theDetails.isComplete()) {
					for (int y=0; y<scenario.getThreadCount(x); y++) {
						sut[threadcount] = new UserThread(theDetails);
						sut[threadcount].setThreadMetrics(metrics);
						sut[threadcount].start();
						threadcount++;
						System.out.println("Thread " + theDetails.getThreadName() + " started");
						try {
							Thread.sleep(rampup * 1000);
						} catch (InterruptedException e) {
							System.out.println("Scenario ramp up interrupted. Ramping down immediately.");
							x = scenario.getThreadCount();
							duration = 0;
							rampdown = 0;
						}
					}
				}
			}
			try {
				Thread.sleep(duration * 1000);
			} catch (InterruptedException e) {
				// Eat the interrupted exception and go on to stop our threads anyway
			}
			System.out.println("Shutting down user threads");
			
			for (int x=0; x<threadcount; x++) {
				sut[x].end();
				System.out.println("Thread " + sut[x].getName() + " shutdown signaled");
				try {
					Thread.sleep(rampdown * 1000);
				} catch (InterruptedException e) {
					System.out.println("Scenario ramp down interrupted. Ramping down immediately.");
					rampdown = 0;
				}
			}
			
			if (agentcount > 0) {
				System.out.println("Shutting down agent threads");
				for (int x=0; x<agentcount; x++) {
					sat[x].end();
					try {
						// Agent thread will be sleeping up to the defined frequency
						Thread.sleep(sat[x].getFrequency() * 1000);
					} catch (InterruptedException e) {
						System.out.println("Agent shut down interrupted.");
					}
				}
			}
		}
		
		System.out.println("Collecting metrics");
		PrintWriter pw = null;
		try {
		    pw = new PrintWriter(new File(scenario.getMetricFile()));
			StringBuilder headings = new StringBuilder();
			headings.append("Time");
			headings.append(",Duration");
			headings.append(",Host");
			headings.append(",Thread");
			headings.append(",Step");
			headings.append(",Status");
			headings.append(",CPU");
			headings.append(",MEM");
			headings.append(",DISKQ");
			headings.append(System.getProperty("line.separator"));
			pw.write(headings.toString());
			
			Vector<MetricDataPoint> finalMetrics = metrics.getMetricData();
			Iterator<MetricDataPoint> itr = finalMetrics.iterator();
			while (itr.hasNext()) {
				StringBuilder data = new StringBuilder();
				MetricDataPoint theData = (MetricDataPoint) itr.next();
				data.append(theData.toString());
				data.append(System.getProperty("line.separator"));
				pw.write(data.toString());
			}
			
		} catch (FileNotFoundException e) {
		    e.printStackTrace();
		}
		pw.close();
		System.out.println("Load test has ended");
	}
}
