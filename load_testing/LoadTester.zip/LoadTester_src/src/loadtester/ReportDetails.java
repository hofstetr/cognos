package loadtester;

import java.util.Vector;

import com.cognos.developer.schemas.bibus._3.ParameterValue;

public class ReportDetails {
	private String ReportName;
	private String ReportPath;
	private String ReportFormat;
	private boolean SaveOutput;
	private String OutputPath;
	@SuppressWarnings("rawtypes")
	private Vector parameters;
	
	ReportDetails (String name, String path, String format, String output, boolean save) {
		ReportName = name;
		ReportPath = path;
		ReportFormat = format;
		SaveOutput = save;
		OutputPath = output;
	}
	
	public String getName () {
		return ReportName;
	}
	public boolean getSaveState () {
		return SaveOutput;
	}
	public String getOutputPath () {
		return OutputPath;
	}
	public String getPath () {
		return ReportPath;
	}
	public String getFormat () {
		return ReportFormat;
	}
	public ParameterValue getParameterValue (int index) {
		ParameterValue pv = null;
		if (index < parameters.size()) {
			pv = ((PromptValues)parameters.get(index)).getNextValue();
		}
		return pv;
	}
	@SuppressWarnings("rawtypes")
	public void setParamterValues (Vector pv) {
		parameters = pv;
	}
	public int getParameterCount () {
		return parameters.size();
	}
}
