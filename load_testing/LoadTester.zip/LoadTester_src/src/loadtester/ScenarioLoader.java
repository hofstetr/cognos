package loadtester;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.cert.CertificateException;
import java.security.cert.CertificateExpiredException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Vector;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.cognos.org.apache.axis.encoding.Base64;

public class ScenarioLoader {
	private boolean loaded = false;
	private Document doc;
	
	ScenarioLoader(String file) {
		// Read scenario information to determine how many threads to run
				File xmlScenario = new File("scenario.xml");
				DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			    DocumentBuilder dBuilder;
				loaded = true;
				try {
					dBuilder = dbFactory.newDocumentBuilder();
					doc = dBuilder.parse(xmlScenario);
				    doc.getDocumentElement().normalize();
				} catch (ParserConfigurationException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SAXException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}	
	}
	public boolean isLoaded () {
		return loaded;
	}
	public int getRampup () {
		int rampup = 0;
		NodeList nListGroup = doc.getElementsByTagName("threadgroup");
	    Node group = nListGroup.item(0);
	    rampup = Integer.parseInt(group.getAttributes().getNamedItem("rampup").getNodeValue());
	    return rampup;
	}
	public int getRampDown () {
		int rampdown = 0;
		NodeList nListGroup = doc.getElementsByTagName("threadgroup");
	    Node group = nListGroup.item(0);
	    rampdown = Integer.parseInt(group.getAttributes().getNamedItem("rampdown").getNodeValue());
	    return rampdown;
	}
	public int getDuration () {
		int duration = 0;
		NodeList nListGroup = doc.getElementsByTagName("threadgroup");
	    Node group = nListGroup.item(0);
	    duration = Integer.parseInt(group.getAttributes().getNamedItem("duration").getNodeValue());
	    return duration;
	}
	public String getMetricFile () {
		NodeList nListMetricFile = doc.getElementsByTagName("metricfile");
	    return nListMetricFile.item(0).getTextContent();
	}
	public int getThreadCount () {
		NodeList nListThreads = doc.getElementsByTagName("thread");
	    return nListThreads.getLength();
	}
	public int getThreadCount (int thread) {
		NodeList nListThreads = doc.getElementsByTagName("thread");
		return Integer.parseInt(nListThreads.item(thread).getAttributes().getNamedItem("count").getNodeValue());
	}
	public String getThreadName (int thread) {
		NodeList nListThreads = doc.getElementsByTagName("thread");
		return nListThreads.item(thread).getAttributes().getNamedItem("name").getNodeValue();
	}
	public int getThinkTime (int thread) {
		int ThinkTime;
		NodeList nListThreads = doc.getElementsByTagName("thread");
		ThinkTime = Integer.parseInt(nListThreads.item(thread).getAttributes().getNamedItem("think").getNodeValue());
		return ThinkTime;
	}
	public String getUser (int thread) {
		NodeList nListThreads = doc.getElementsByTagName("userid");
		return nListThreads.item(thread).getTextContent();
	}
	public String getPassport (int thread) {
		NodeList nListThreads = doc.getElementsByTagName("passport");
		return nListThreads.item(thread).getTextContent();
	}
	public String getPassword (int thread) {
        String thePassword = null;
		
        NodeList nListThreads = doc.getElementsByTagName("password");
		String theEncPassword = nListThreads.item(thread).getTextContent();
		
		// Reconstruct the private key from key file
		File private_key_der = new File("private.der");
        File certificate_der = new File("certificate.der");

		FileInputStream fis;
		try {
			fis = new FileInputStream(private_key_der);
			DataInputStream dis = new DataInputStream(fis);
	        byte[]  keyBytes = new byte[(int)private_key_der.length()];
	        dis.readFully(keyBytes);
	        dis.close();
	        PKCS8EncodedKeySpec priv_spec = new PKCS8EncodedKeySpec(keyBytes);
	        KeyFactory keyFac = KeyFactory.getInstance("RSA");
	        PrivateKey rsaPrivKey = keyFac.generatePrivate(priv_spec);

	        // Create the reverse encryption cipher from private key file
	        Cipher rsaCipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
	        rsaCipher.init(Cipher.DECRYPT_MODE, rsaPrivKey);

	        // Decode the binary 64 encoded cipher text and reassemble the bytes into a string
	        byte[] decoded_bytes = rsaCipher.doFinal(Base64.decode(theEncPassword));
	        thePassword = new String(decoded_bytes, "UTF8");
	        
	        // Reconstruct the X509 certificate object from certificate file
        	fis = new FileInputStream(certificate_der);
        	CertificateFactory certificateFactory = CertificateFactory.getInstance("X.509");
            X509Certificate certificate = (X509Certificate)certificateFactory.generateCertificate(fis);
            certificate.checkValidity();
            
            // Create the encryption cipher from the certificate's public key
            PublicKey rsaPubKey = certificate.getPublicKey();
            Cipher x509Cipher = Cipher.getInstance("RSA/ECB/PKCS1PADDING");
            x509Cipher.init(Cipher.ENCRYPT_MODE, rsaPubKey);
            
            // Encrypt the clear text password to ensure the certificate hasn't expired.
            theEncPassword = Base64.encode(x509Cipher.doFinal(thePassword.getBytes()));
            
	        
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvalidKeySpecException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvalidKeyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (BadPaddingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (CertificateExpiredException e) {
			System.out.println("Tried to use an expired certificate. Please contact IBM to renew the engagement.");
			e.printStackTrace();
			System.exit(1);
		}catch (CertificateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// handle special characters in passwords
		thePassword = thePassword.replaceAll("&", "&amp;");
		thePassword = thePassword.replaceAll("<", "<");
		return thePassword;
	}
	
	public String getNamespace (int thread) {
		NodeList nListThreads = doc.getElementsByTagName("namespace");
		return nListThreads.item(thread).getTextContent();
	}
	public String getDispatcher (int thread) {
		NodeList nListDispatchers = doc.getElementsByTagName("dispatcher");
		return nListDispatchers.item(thread).getTextContent();
	}
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public ReportDetails[] getReportDetails (int thread) {
		ReportDetails reports[]=null;
		Node nReports = doc.getElementsByTagName("reports").item(thread);
		if(nReports instanceof Element) {
		    Element elReports = (Element)nReports;
		    NodeList nListofReports = elReports.getElementsByTagName("report");
			reports = new ReportDetails[nListofReports.getLength()];
			Vector pv = new Vector();
			for (int x=0; x<nListofReports.getLength(); x++) {
				Element report = (Element)nListofReports.item(x);
				
				// Get the name of the report from the XML attribute
				String name = report.getAttributes().getNamedItem("name").getNodeValue();
				
				// Determine if the output should be saved according to the XML
				String save = report.getAttributes().getNamedItem("save").getNodeValue();
				
				// Get the path of the report from the expected single XML element
				NodeList nListofPaths = report.getElementsByTagName("path");
				String path = null;
				if (nListofPaths.getLength() == 1) {
					path = nListofPaths.item(0).getTextContent();
				}
				
				// Get the format for the report from the expected single XML element
				NodeList nListofFormats = report.getElementsByTagName("format");
				String format = null;
				if (nListofFormats.getLength() == 1) {
					format = nListofFormats.item(0).getTextContent();
				}
				
				// Get the output path if outputs are to be saved
				NodeList nListofOutputs = report.getElementsByTagName("outputpath");
				String output = null;
				if (nListofOutputs.getLength() == 1) {
					output = nListofOutputs.item(0).getTextContent();
				}
				
				// Create a new report details object from the above information
				reports[x] = new ReportDetails(name, path, format, output, save.compareToIgnoreCase("true") == 0 ? true : false); 
				
				// Now add any prompt values
				NodeList nPromptElements = report.getElementsByTagName("prompts");
				if (nPromptElements.getLength() == 1) {
					Element parent = (Element) nPromptElements.item(0);
					
					// For now only handle simple parameters (i.e. single selection)
					NodeList nListofPrompts = parent.getChildNodes();
					
					for (int i=0; i<nListofPrompts.getLength(); i++) {
						if (nListofPrompts.item(i).getNodeName().compareToIgnoreCase("simple") == 0) {
							Element prompt = (Element) nListofPrompts.item(i);
							String parameter = prompt.getAttribute("name");
							String[] useValues = null;
							String[] displayValues = null;
							NodeList ListofUseValues = prompt.getElementsByTagName("use");
							for (int j=0; j<ListofUseValues.getLength(); j++) {
								String csvalues = ListofUseValues.item(j).getTextContent();
								useValues = csvalues.split(",");
							}
							NodeList ListofDisplayValues = prompt.getElementsByTagName("display");
							for (int j=0; j<ListofDisplayValues.getLength(); j++) {
								String csvalues = ListofDisplayValues.item(0).getTextContent();
								displayValues = csvalues.split(",");
							}
							PromptValues parameters = new PromptValues(parameter);
							for (int j=0; j<useValues.length; j++) {
								parameters.addSimpleValue(useValues[j].trim(), displayValues[j].trim());
							}
							
							pv.add(parameters);
						}
						else if (nListofPrompts.item(i).getNodeName().compareToIgnoreCase("multi") == 0) {
							Element prompt = (Element) nListofPrompts.item(i);
							String parameter = prompt.getAttribute("name");
							String[] useValues = null;
							String[] displayValues = null;
							NodeList ListofUseValues = prompt.getElementsByTagName("use");
							for (int j=0; j<ListofUseValues.getLength(); j++) {
								String csvalues = ListofUseValues.item(j).getTextContent();
								useValues = csvalues.split("&");
							}
							NodeList ListofDisplayValues = prompt.getElementsByTagName("display");
							for (int j=0; j<ListofDisplayValues.getLength(); j++) {
								String csvalues = ListofDisplayValues.item(0).getTextContent();
								displayValues = csvalues.split("&");
							}
							PromptValues parameters = new PromptValues(parameter);
							for (int j=0; j<useValues.length; j++) {
								parameters.addMultiValue(useValues[j].split(","), displayValues[j].split(","));
							}
							
							pv.add(parameters);
						}
						else if (nListofPrompts.item(i).getNodeName().compareToIgnoreCase("range") == 0) {
							Element prompt = (Element) nListofPrompts.item(i);
							String parameter = prompt.getAttribute("name");
							String[] fromValues = null;
							String[] toValues = null;
							NodeList ListofFromValues = prompt.getElementsByTagName("from");
							for (int j=0; j<ListofFromValues.getLength(); j++) {
								String csvalues = ListofFromValues.item(j).getTextContent();
								fromValues = csvalues.split(",");
							}
							NodeList ListofToValues = prompt.getElementsByTagName("to");
							for (int j=0; j<ListofToValues.getLength(); j++) {
								String csvalues = ListofToValues.item(0).getTextContent();
								toValues = csvalues.split(",");
							}
							PromptValues parameters = new PromptValues(parameter);
							for (int j=0; j<fromValues.length; j++) {
								parameters.addRangeValue(fromValues[j], toValues[j]);
							}
							
							pv.add(parameters);
						}
					}
				}
				reports[x].setParamterValues(pv);
			}
		}	
		return reports;
	}
	
	public String[] getServerAgents () {
		String agents[] = null;
		NodeList nAgents = doc.getElementsByTagName("serveragent");
		if (nAgents.getLength() > 0) {
			agents = new String[nAgents.getLength()];
			for (int x=0; x<nAgents.getLength(); x++) {
				agents[x] = nAgents.item(x).getAttributes().getNamedItem("address").getTextContent();
			}
		}
		return agents;
	}
	
	public String[] getAgentFrequencies () {
		String frequencies[] = null;
		NodeList nAgents = doc.getElementsByTagName("serveragent");
		if (nAgents.getLength() > 0) {
			frequencies = new String[nAgents.getLength()];
			for (int x=0; x<nAgents.getLength(); x++) {
				frequencies[x] = nAgents.item(x).getAttributes().getNamedItem("frequency").getTextContent();
			}
		}
		return frequencies;
	}
	
	public ThreadDetails getThreadDetails (int thread) {
		ThreadDetails theDetails = new ThreadDetails();
		theDetails.setThreadName(getThreadName(thread));
		theDetails.setPassport(getPassport(thread));
		if (theDetails.getPassport() == null) {
			theDetails.setNamespace(getNamespace(thread));
			theDetails.setUserID(getUser(thread));
			theDetails.setUserPWD(getPassword(thread));
		}
		theDetails.setDispatcher(getDispatcher(thread));
		theDetails.setReportDetails(getReportDetails(thread));
		theDetails.setThinkTime(getThinkTime(thread));
		return theDetails;
	}
}
