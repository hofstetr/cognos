package loadtester;

import java.util.Vector;

import com.cognos.developer.schemas.bibus._3.ParameterValue;
import com.cognos.developer.schemas.bibus._3.ParmValueItem;
import com.cognos.developer.schemas.bibus._3.SimpleParmValueItem;
import com.cognos.developer.schemas.bibus._3.BoundRangeParmValueItem;

public class PromptValues {
	private String name;
	private int pointer;
	private Vector<ParameterValue> values;
	
	PromptValues(String pName) {name = pName; pointer = 0; values = new Vector<ParameterValue>();}
	
	public void addSimpleValue(String useValue, String displayValue) {
		ParameterValue pv = new ParameterValue();
		ParmValueItem[] pvi = new ParmValueItem[1];
		SimpleParmValueItem item = new SimpleParmValueItem();
		item.setUse(useValue.trim().replaceAll("\r", "").replaceAll("\n", ""));
		item.setDisplay(displayValue.trim().replaceAll("\r", "").replaceAll("\n", ""));
		item.setInclusive(true);

		pvi[0] = item;
		pv.setName(name);
		pv.setValue(pvi);
		
		values.add(pv);
	}
	
	public void addMultiValue(String useValue[], String displayValue[]) {
		ParameterValue pv = new ParameterValue();
		ParmValueItem[] pvi = new ParmValueItem[useValue.length];

		for (int i=0; i<useValue.length; i++) {
			SimpleParmValueItem item = new SimpleParmValueItem();
			item.setUse(useValue[i].trim().replaceAll("\r", "").replaceAll("\n", ""));
			item.setDisplay(displayValue[i].trim().replaceAll("\r", "").replaceAll("\n", ""));
			item.setInclusive(true);
			pvi[i] = item;
		}
		pv.setName(name);
		pv.setValue(pvi);
		
		values.add(pv);
	}
	
	public void addRangeValue(String fromValue, String toValue) {
		ParameterValue pv = new ParameterValue();
		ParmValueItem[] pvi = new ParmValueItem[1];

		// First load the start and ending values into a SimpleParmValueItem
		SimpleParmValueItem itemStart = new SimpleParmValueItem();
		itemStart.setUse(fromValue.trim().replaceAll("\r", "").replaceAll("\n", ""));
		itemStart.setDisplay(fromValue.trim().replaceAll("\r", "").replaceAll("\n", ""));
		SimpleParmValueItem itemEnd = new SimpleParmValueItem();
		itemEnd.setUse(toValue.trim().replaceAll("\r", "").replaceAll("\n", ""));
		itemEnd.setDisplay(toValue.trim().replaceAll("\r", "").replaceAll("\n", ""));
		
		BoundRangeParmValueItem item = new BoundRangeParmValueItem();
		item.setStart(itemStart);
		item.setEnd(itemEnd);
		item.setInclusive(true);
		pvi[0] = item;

		pv.setName(name);
		pv.setValue(pvi);
		
		values.add(pv);
	}
	
	public String getName() {
		return name;
	}
	
	public ParameterValue getNextValue() {
		if (pointer >= values.size()) {
			pointer = 0;
		}
		return values.get(pointer++);
	}
}
