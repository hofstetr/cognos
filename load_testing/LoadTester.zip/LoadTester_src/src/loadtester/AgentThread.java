package loadtester;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.net.Socket;
import java.time.Instant;

public class AgentThread extends Thread {
	private String host;
	private int frequency;
	private Socket agent;
	private PrintWriter out;
	private BufferedReader in;
	private ThreadMetrics metrics;
	private volatile boolean runflag = true;
	
	AgentThread (String server, int port, int freq) {
		frequency = freq;
		host = server;
		// Attempt connecting to Perfmon ServerAgent
		try {
			agent = new Socket(host, port);
			out = new PrintWriter(agent.getOutputStream(), true);
		    in = new BufferedReader(new InputStreamReader(agent.getInputStream()));
		} catch (IOException e) {
			System.out.println("Unable to connect to PerfMon agent. System metrics will not be collected.");
		}
	}
	
	public void setThreadMetrics(ThreadMetrics m) {
		metrics = m;
	}
	
	public int getFrequency () {
		return frequency;
	}
	
	public void run() {
		double cpu = 0;
		double freememory = 0;
		double diskio = 0;
		while(runflag) {
			try {
				Thread.sleep(frequency * 1000);
			} catch (InterruptedException e) {
				// If we are interrupted it is probably to shut down
				end();
			}
			
			out.write("metrics-single:cpu\tmemory:actualfree\tmemory:actualused\tdisks:queue\n");
			out.flush();
			try {
				String socketInput = in.readLine();
				String metricValues[] = socketInput.split("\t");
				if (metricValues.length == 4) {
					cpu = Float.parseFloat(metricValues[0]);
					freememory = new BigDecimal(metricValues[1]).doubleValue();
					diskio = Float.parseFloat(metricValues[3]);
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
			metrics.add(Instant.now(), 0, host, this.getName(), "resources", true, cpu, freememory, diskio);
		}
		
		try {
			agent.shutdownInput();
			agent.shutdownOutput();
			in.close();
			out.close();
			agent.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void end() {
		runflag = false;
	}
}
