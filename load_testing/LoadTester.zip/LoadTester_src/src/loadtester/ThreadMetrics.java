package loadtester;

import java.time.Instant;
import java.util.Vector;

public class ThreadMetrics {
	private Vector<MetricDataPoint> metricData;
	
	ThreadMetrics() {metricData = new Vector<MetricDataPoint>();}
	
	public synchronized void add(Instant instant, int duration, String host, String name, String step, boolean status, double servercpu, double servermem, double serverdisk) {
		MetricDataPoint theData = new MetricDataPoint (instant, duration, host, name, step, status, servercpu, servermem, serverdisk);
		metricData.add(theData);
	}
	
	public Vector<MetricDataPoint> getMetricData() {
		return metricData;
	}
}
